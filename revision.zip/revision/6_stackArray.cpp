//Question 1
#include <iostream>
#include <string>
using namespace std;

const int SIZE = 5;
struct Student
{
    int studId, age;
    string studName;
};

int top;

void push(Student stud[]) //where the input is inside the function
{
    if (top < SIZE - 1)
    {
        top++;
        cin.clear();
        cin.ignore(100, '\n');
        cout << "Enter Student Details\n";
        cout << "Student Name: ";
        getline(cin, stud[top].studName);
        cout << "Student ID: ";
        cin >> stud[top].studId;
        cout << "Student Age: ";
        cin >> stud[top].age;
        cout << "\nStudent Added Sccuessfully.\n" << endl;
    }
    else
    {
        cout << "Space is FULL!\n" << endl;
    }
    system("pause");
}

void pop(Student stud[])
{
    /*d) Complete the function definition for pop*/
    if (top != -1)
    {
        cout << "Deleting " << stud[top].studId << ", " << stud[top].studName << ", Age: " << stud[top].age << endl;
        cout << "\n";
        stud[top--] = { 0, 0, "" };
    }
    else
    {
        cout << "Space is empty\n" << endl;
    }
    system("pause");
}

void display(Student stud[])
{
    /*e) Complete the function definition for display*/
    if (top == -1) 
    {
        cout << "Empty" << endl;
    }
    else 
    {
        cout << "Student List:\n\n";
        for (int i = top; i >= 0; i--) {
            cout << "Student ID:  " << stud[i].studId << endl
                << "Student name: " << stud[i].studName << endl
                << "Student age: " << stud[i].age << endl;
            cout << "\n";
        }
    }
    
    system("pause");
}

int main()
{
    Student studArr[SIZE] = { };
    int option;
    top = -1;

    do
    {
        system("cls");
        cout << "1 - Add student" << endl;
        cout << "2 - Delete student" << endl;
        cout << "3 - Display student" << endl;
        cout << "4 - Exit" << endl;
        cout << "Please select an option: ";
        cin >> option;
        system("cls");

        switch (option)
        {
        case 1: /*f) Call the push function*/
            push(studArr);
            break;
        case 2: /*h) Call the pop function*/
            pop(studArr);
            break;
        case 3: /*i) Call the display function*/
            display(studArr);
            break;
        case 4: 
            cout << "Exit" << endl; 
            break;
        default: 
            cout << "Please select an option from 1 - 4" << endl;
            break;
        }
    } while (option != 4);
}