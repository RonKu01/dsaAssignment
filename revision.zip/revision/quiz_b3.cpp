// Ku Ming Roong 0133750 Question B3

#include<iostream>
using namespace std;

const int DEPTH = 3;

char bPTree[DEPTH*DEPTH] = {'\0', '+','*','-','5','4','3', '2'};

int valid(int index)
{
  return ((index < DEPTH*DEPTH) && bPTree[index]);
}

int leftChild(int index)
{         return index * 2; }

int rightChild (int index)
{        return (index * 2) + 1;        }

void displayData(int index){
  cout << bPTree[index] << "\t"; }

void preOrder(int index){
  if(valid(index))
  {
    displayData(index);
    preOrder(leftChild(index));
    preOrder(rightChild(index));
  }
}

void inOrder(int index){
  if(valid(index))
  {
    inOrder(leftChild(index));
    displayData(index);
    inOrder(rightChild(index));
  }
}

void postOrder(int index){ 
  if(valid(index))
  {
    postOrder(leftChild(index));
    postOrder(rightChild(index));
    displayData(index);
  }
}

char  findRightChild(char op)
{
    int index;
    for(index = 1; index < DEPTH * DEPTH; index++)
    {
        if (op == bPTree[index]){
            break;
        }
    }
    return bPTree[rightChild(index)];
}

char  findLeftChild(char op)
{
    int index;
    for(index = 1; index < DEPTH * DEPTH; index++)
    {
        if (op == bPTree[index]){
            break;
        }
    }
    return bPTree[leftChild(index)];//return bPTree[6];
}


int main()
{
    preOrder(1);
    cout<< "Prefix" << endl;

    postOrder(1);
    cout << "Postfix" << endl;

    inOrder(1);
    cout << "Infix " << endl;
}

