#include <iostream>
using namespace std;

int const SIZE = 4;
double qArray [SIZE];
int tail = -1, head = -1; 

void enqueue (double val){
    //a) write the c++ statements to add val to the qArray if the qArray is not full. if the qArray is full display an appropriate message.
    if (tail == SIZE -1) {
        cout << "Full" << endl;
    } else {
        if (head = -1) {
            head = 0;
        }
    tail++;
    qArray[tail] = val;
    }
}

void dequeue(){
    if (head == -1){
    cout << "No values in the queue to removed";
    }else{
        //b) write the c++ statements to display and remove the front value of the qArray. Ensure once the front value has been removed other values can be aded to qArray.
        cout << "Values removed " << qArray[head] << endl;
        for(int i = head; i <= tail; i ++){
            qArray[i] = qArray[i+1];
        }
        tail--; 
    }
}

void display(){
    if (head == -1 || qArray[head] == 0){
        cout << "No values to display " << endl; 
    }
    else{
        cout << "\nValues in the queue: " << endl;
        for(int i = head; i <= tail; i ++){
            if(qArray[i] != 0)
            cout << qArray[i] << endl;
        }
    }
}

int main(){
    enqueue(29.28);
    enqueue(85.81);
    enqueue(11.37);
    enqueue(28.77);
    enqueue(88.19);
    display();
    dequeue();
    display();
    dequeue();
    display();
    dequeue();
    display();
    dequeue();
    display();
}