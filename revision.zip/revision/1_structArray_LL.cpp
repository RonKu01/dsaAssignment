// // Static data type – arrays (integers, string, structures) - limited in size

#include<iostream>
using namespace std;
const int SIZE=5;
struct Person
{
int id;
string name;
int age;
};
int main()
{
    int arr[SIZE] = {233,234,235,236,237};
    struct Person p;
    //a) initialize an array of Persons with data 
    Person dependant[SIZE] = {{123, "Ali", 22}, {133, "Muthu",33}, {3, "Ahmad",20},
        {224, "Baba", 25}, {420, "Shaun", 19}};

    //b) Declare only an array of Persons without initializing
    Person dep[SIZE] = {};

    //c) Assign values to at least 2 elements of the array above
    struct Person human_1 = {12345, "Michael", 52};
    dep[0].id = 2828;
    dep[0].name = "Aziz";
    dep[0].age=24;
    dep[1].id = 133;
    dep[1].name= "James";
    dep[1].age=33;
    dep[2].id = 31;
    dep[2].name = "Michael";
    dep[2].age = 52;


    //d) Display all values in both the arrays
    for(int i = 0; i < SIZE; i++)
    {
    cout << "ID: " << dependant[i].id << endl 
    << "Name: " << dependant[i].name << endl 
    << "Age: " << dependant[i].age << endl << endl;
    }

    //e) use enhanced for loop
    for (Person d: dep) {
    cout << "ID: " << d.id << endl 
        << "Name: " << d.name << endl 
        << "Age: " << d.age << endl << endl;

    }
    
    for (int i; i<5; i++)
    {
    cout << "ID: " << dependant[i].id << endl 
    << "Name: " << dependant[i].name << endl 
    << "Age: " << dependant[i].age << endl << endl;
    }

}


// // Dynamic data types – structures – variables declared are pointer variables – not limited 
// // Justify which data type you will use:

// #include<iostream>
// using namespace std;
// const int SIZE=5;

// struct Person
// {
// int id;
// string name;
// int age;
// Person *nP;
// };

// int main(){
//     Person* visitor1 = new Person;
//     Person* visitor2 = new Person;
//     Person* visitor3 = new Person;	
//     Person* visitor4 = new Person;


//     //Populate data to visitor1, ...
//     visitor1->id = 2929;
//     visitor1->name = "Sam";
//     visitor1->age = 49;

//     visitor2->id = 2022;
//     visitor2->name = "Michael";
//     visitor2->age = 49;

//     visitor3->id=33;
//     visitor3->name = "John";
//     visitor3->age = 12;
    
//     visitor4->id = 2889;
//     visitor4->name = "Jamy";
//     visitor4->age = 58;

//     //Link the visitors 
//     visitor1->nP = visitor2;
//     visitor2->nP = visitor3;
//     visitor3->nP = visitor4;
//     visitor4->nP = NULL;

//     while(visitor1 != NULL)
//     {
//         cout << "Name: " <<  visitor1->name << endl;

//         //navigate through the list
//         visitor1 = visitor1->nP;
//     }
// }

// Sample question 
// 1 - write simple C++ codes to demonstrate the difference between static and dynamic data structures.
// 2 – Complete the program that uses dynamic data structure.


