#include<string>
#include<iostream>
using namespace std;

/*Initialize the string array for the names of the vertices / locations*/
string location[4] = {"Manchester", "Leeds", "Sheffield", "Liverpool"};

/*Building the graph with the weights associated with the graph*/
int dist[4][4] = {{0, 71, 61, 56},
                  {71, 0, 59, 123},                      
                  {61, 59, 0, 125},
                  {56, 123, 125, 0}};

int main()
{ 
  int to, from;//represent the index to read the locations
  string placeTo, placeFrom;


  /*Prompt user for departure location  and read the location*/
  for(int i = 0; i < 4; i++){
    cout << i+1 << " for " << location[i] << endl;
  }
  
  cout << "Please enter your starting location based on the value : ";
  cin >> from;
  cout << "Starting from " << location[from-1] << endl << endl;

  
  
//   /*Prompt user for destination location  and read the location*/
 /*Prompt user for departure location  and read the location*/
  for(int i = 0; i < 4; i++){
    cout << i+1 << " for " << location[i] << endl;
  }
  cout << "Please enter your destination location based on the value : " << endl;
  cin >> to;
  cout << "Destination to " << location[to-1] << endl << endl;
  
//   /*Use a for loop to search within the location array for the place to */
  if(to == from){
    cout << "Same place :(" << endl;
  }else{
    cout << "Distance between " << location[to-1] << " and " << location[from-1] << " is " << dist[from-1][to-1] << endl;
  }
}