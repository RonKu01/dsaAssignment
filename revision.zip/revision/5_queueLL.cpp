#include <iostream>

using namespace std;

struct Student{
  int studId, studAge;
  string studName;
  Student* nxtStud;
};

bool isEmpty(Student* front){
  if(front != NULL){
    return false;
  }else{
    return true;
  }
}

Student* enqueue(Student* nStud, Student* front, Student* rear){
    rear -> nxtStud = nStud;
    rear = nStud;
    return rear;
}

Student* dequeue(Student* front){
  Student* navi = front;
  cout << "Deleting " << navi -> studId << ": " << navi -> studName << endl;
  navi = navi -> nxtStud;
  front = navi;
  return front;
}

void displayList(Student*front){
  Student*navi=front;
  while(navi!=NULL){
    cout<<"Name: "<<navi->studName<<endl<<"Id: "<<navi->studId<<endl<<"Age: "<<navi->studAge<<endl;
    navi=navi->nxtStud;
  }
}

int main()
{
	Student *front, *rear, *newStudent;
	int option;

	front = NULL;
	rear = NULL;

	do
	{
		cout << "\nEnter option : 1 to enqueue, 2 to dequeue, 3 to display, any other value to exit :" << endl;
		cin >> option;
		if (option == 1 || option == 2 || option == 3)
		{
			switch (option)
			{
			case 1:
			{
				Student* newStudent = new Student;
				cout << "Enter id, age and name of student " << endl;
				cin >> newStudent->studId >> newStudent->studAge;
				cin.ignore();
				getline(cin, newStudent->studName, '\n');
				newStudent->nxtStud = NULL;

        if(front == NULL){
          front = newStudent;
          rear = newStudent;
        }else{
				rear = enqueue(newStudent, front, rear);
        }
				break;
			}
			case 2:
			{
				if (front == NULL)
				{
					cout << "Nothing to delete" << endl;
				}
				else
				{
					front = dequeue(front);
				}
				break;
			}
			case 3:
			{
				if (front == NULL)
					cout << "Nothing to show" << endl;
				else
					displayList(front);
				break;
			}
			}//end of switch

		}
		else
		{
			option = -1;
      cout << "Exitting..." << endl;
			break;
		}

	} while (option != -1);

}