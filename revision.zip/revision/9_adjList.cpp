#include<iostream>
using namespace std;

/*1 - Allocate / Assign a constant identifier for each vertex */
const int MANC = 0;
const int LEED = 1;
const int LVRP = 2;
const int SHFFD = 3;

/*2 - Declare the structure for edge called Route - use it in Venue structure but will only define it after the structure Venue is done.*/
struct Route;

/*3 - Define the structure for vertex called Venue - it contains name, and address of the next route */
struct Venue
{
  string name;
  Route *nxtR;//this is the reason we needed to declare Route in line 11
};
/*4 - Define the structure for edge called Route  - it contains distance, name of the destination and address of the next route */
struct Route
{
  int distance;
  Venue *nVen;
  Route *nxtRPtr;
};

/*4 - Creating the array of venue list which is not connected yet*/
Venue vList[4] = {{"Manchester", NULL},
                  {"Leeds", NULL},
		              {"Liverpool", NULL},
		              {"Sheffield", NULL}};

/*5 - Define a function called setLinks(Venue *from, Venue *to, int distance) */
void setLinks(Venue *from, Venue *to, int dist)
{
    Route *r = new Route();
    r->distance = dist;
    
    r->nVen = to;
    r->nxtRPtr = from->nxtR;
    from->nxtR = r;  
}

/*Define a function called buildGraph() that creates the graph using the setLinks function*/
void buildGraph()
{
  setLinks(&vList[MANC], &vList[LEED], 71);
  setLinks(&vList[MANC], &vList[LVRP], 56);
  setLinks(&vList[MANC], &vList[SHFFD], 61);

  setLinks(&vList[LVRP], &vList[SHFFD], 125);
  setLinks(&vList[LVRP], &vList[LEED], 123);
  setLinks(&vList[LVRP], &vList[MANC], 56);
  
  setLinks(&vList[SHFFD], &vList[LEED], 59);
  setLinks(&vList[SHFFD], &vList[LVRP], 125);
  setLinks(&vList[SHFFD], &vList[MANC], 61);

  setLinks(&vList[LEED], &vList[MANC], 71);
  setLinks(&vList[LEED], &vList[SHFFD], 59);
  setLinks(&vList[LEED], &vList[LVRP], 123);

}

/*define a function called calculateDistance that accepts two vertex (Venue)(arguments returns the value stored in the edge (Route)*/
int calculateDistance(Venue *to, Venue *from)
{
  Route* r = from->nxtR;
  while(r->nVen != to)//moving along the list
    {
      r = r->nxtRPtr;
    }
  return r->distance;//KIV

  
}


/*Main function - 1 - build the graph, 2 - prompt user for from and to, 3 - display the distance between the from and to*/
int main()
{
  int from, to;

  buildGraph();

  cout << "Enter where you are from" << endl 
    << MANC << " for Manchester " << endl
    << LEED << " for Leeds " << endl
    << LVRP << " for Liverpool " << endl
    << SHFFD << " for Sheffield " << endl;

  cin >> from;
  
  cout << "Enter where you are going" << endl 
    << MANC << " for Manchester " << endl
    << LEED << " for Leeds " << endl
    << LVRP << " for Liverpool " << endl
    << SHFFD << " for Sheffield " << endl;

  cin >> to;

  Venue *toV = &vList[to];
  Venue *fromV = &vList[from];
  cout << " You are going from " << fromV->name << " to " << toV->name << endl;
  
  cout << "Distance is " << calculateDistance(toV, fromV) << endl;
    
}

