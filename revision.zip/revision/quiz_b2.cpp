#include <iostream>

using namespace std;

bool isEmpty(int rear)
{
	return (rear == -1) ? true : false;
}

void display(int arr[], int rear, int front)
{
	if (isEmpty(rear))
	{
		cout << "Empty Queue" << endl;
	}
	else
	{
		for (int i = front; i <= rear; i++)
		{
			cout << arr[i] << endl;
		}
	}
}

void dequeue(int arr[], int& rear, int& front){
	if (isEmpty(rear))
	{
		cout << "Empty queue" << endl;
	}
	else
	{
		cout << "Deleting " << arr[front] << endl;
        cout << "Values in the queue now :" << endl;

		for (int i = front; i < rear; i++)
		{
            arr[i] = arr[i+1];
		}
		rear--;


	}
}

int main(){

    int arr[] = {28, 43, 7, -5 , 65, 53};
    char opt;
    int front = 0, rear = 5;

    do {
        cout << "Do you wish to delete ? Y for yes or N for no ";
        cin >> opt;

        if(opt == 'y'){
           dequeue(arr, rear, front);
           display(arr, rear, front);
        } else {
            break;
        }

    } while (opt != 'n');
}