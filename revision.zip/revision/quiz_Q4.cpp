#include<iostream>
#include<string>
using namespace std;

struct Donor
{
  string id, fullName;
  double amountPledge;
  Donor *anotherDonor;
};

/*a)    Write C++ statements to complete the function defintion for display()
        which will display the values stored in donor1 and donor2. */
void display(Donor *d)
{   
    Donor* navi = d;
    while (navi!= NULL){
        cout << "ID: " << d->id << endl;
        cout << "Name: " << d->fullName << endl;
        cout << "Amount Pledge: " << d->amountPledge << endl;
        navi = navi->anotherDonor;
    }
}

int main()
{
    Donor* donor1 = new Donor;
    Donor* donor2 = new Donor;
    
    /*b)    Write C++ statements to assign your own set of values to donor1 and 
        donor2. */
donor1->id = "101";
donor1->fullName = "Ron";
donor1->amountPledge = 3;

donor2->id = "102";
donor2->fullName = "Ku";
donor2->amountPledge = 5;
        
    
    /*c)    Write C++ statements to link donor1 to donor2. */

    Donor* head = donor1;
    donor1->anotherDonor = donor2;
    donor2->anotherDonor = NULL;
    
    display(donor1);
    
}

        
        