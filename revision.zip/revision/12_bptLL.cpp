#include<iostream>
#include<string>

using namespace std;

struct NodeLL {
char ope;
NodeLL* left;
NodeLL* right;
};

NodeLL* initialNewNode(char ope) {
NodeLL* newNode = new NodeLL;
newNode->left = NULL;
newNode->ope = ope;
newNode->right = NULL;

 return newNode;
}

void display(char data) {
cout << data << endl;
}

void preorder(NodeLL* node) {
if (node) //there is an address
{
display(node->ope);//parent
preorder(node->left);//left
preorder(node->right);//right
}
}

void inOrder(NodeLL* node) {
if (node) {
inOrder(node->left);
display(node->ope);
inOrder(node->right);
}
}

void postOder(NodeLL* node) {
if (node) {
postOder(node->left);
postOder(node->right);
display(node->ope);
}
}

int main() {
/*Declare the root and the parents*/
NodeLL* root;
NodeLL* parent1;
NodeLL* parent2;
/*Build the tree*/
root = initialNewNode('*');
root->left = initialNewNode('-');
root->right = initialNewNode('+');

parent1 = root->left;
parent1->left = initialNewNode('8');
parent1->right = initialNewNode('3');

 parent2 = root->right;
parent2->left = initialNewNode('4');
parent2->right = initialNewNode('5');
cout << "Preorder" << endl;
preorder(root);
cout << "Inorder" << endl;
inOrder(root);
cout << "Postorder" << endl;
postOder(root);
}