#include <iostream>
#include <string>

using namespace std;

struct Prod
{
    string prodDesc, prodId;
    double priceUnit;
    Prod *nProd, *pProd;
};

void addToBack(Prod *&front, Prod *product, Prod *&rear){
    product->nProd = NULL;
    //a) Write the C++ statement to attach the product to front if the list is empty.
    if (front == NULL){
      product->pProd = NULL;
      front = product;
    }

    while (rear->nProd != NULL)
    {
        rear = rear->nProd;
    }

    //b) Write the C++ statements to attach the product to rear
    rear->nProd = product;
    product->pProd = rear;
    rear = product;
}

void displayEach(Prod *eachP){
    cout << "Product Description: " << eachP->prodDesc << endl
        << "Product Id: " << eachP->prodId << endl
        << "Product per unit RM: " << eachP->priceUnit << endl << endl;
}

void display(Prod *front){
    //c) Write the C++ statements to dispaly the list from front to rear. Use the displayEach function. 
  while(front != NULL){
    displayEach(front);
    front = front->nProd;
  }

  displayEach(front);
}

void displayRev(Prod *r){
    //d) Write the C++ statements to display the list from rear to front. Use displayEach function. 
    while(r != NULL){
      displayEach(r);
      r = r->pProd;
    }
}

int main(){
    Prod* whiteBoard = new Prod;
    Prod* softBoard = new Prod;

    Prod* front = whiteBoard;
    Prod* rear = front;

    whiteBoard->prodDesc = "White Board";
    whiteBoard->prodId = "WB";
    whiteBoard->priceUnit = 230.00;

    softBoard->prodDesc = "Soft Board";
    softBoard->prodId = "SB";
    softBoard->priceUnit = 200.00;

    whiteBoard->pProd = NULL;
    whiteBoard->nProd = softBoard;
    softBoard->pProd = whiteBoard;
    softBoard->nProd = NULL;

    Prod *waterPick = new Prod;

    waterPick->prodDesc = "Waterpick";
    waterPick->prodId = "WP";
    waterPick->priceUnit = 140.00;

    addToBack(front, waterPick, rear);

    cout << "Display from back to front " << endl;
    displayRev(rear);

    cout << "Display from front to back " << endl;
    display(front);


}