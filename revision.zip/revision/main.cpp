#include <iostream>

using namespace std;

// struct Node {
//     int data;
//     Node* nxt;
// };


struct History {
    string name;
    int age;
    string venue;
    History* nxtHis;
};

void displayList(History *head){
    History* current = head;

    while (current != NULL){
        cout << current->name << " " << current->age << " " << current->venue << endl;
        current = current->nxtHis;
    }
}

History* addToBegin(History *newHistory, History *head){
    newHistory->nxtHis = head;
    head = newHistory;
    return head;
}

History* addToEnd(History *newHistory, History *head){
    newHistory->nxtHis = NULL;
    History* navi = head;
    while (navi->nxtHis != NULL){
        navi=navi->nxtHis;
    }
    navi->nxtHis = newHistory;
    return head;
}

History* addToN(History *newHistory, History *head){
    int n=3;
    History* navi = head;
    for(int loop = 1; loop < n-1; loop++){
        navi = navi->nxtHis;
    }
    newHistory->nxtHis = navi->nxtHis;
    navi->nxtHis = newHistory;

    return head;
}

History* delAtBegin(History* head){
    head = head->nxtHis;
    return head;
}

History* delAtEnd(History* head){
    History* navi = head;
    while(navi->nxtHis->nxtHis != NULL){
        navi = navi->nxtHis;
    }
    navi->nxtHis = NULL;
    return head;
}

History* delAtN(History* head){
    int n=3;
    History* navi = head;
    for(int loop = 2; loop < n; loop++){
        if(navi->nxtHis != NULL){
            navi = navi->nxtHis;
        }
    }
    navi->nxtHis = navi->nxtHis->nxtHis;
    return head;
}

int main() {

    History* head;
    History* current;

    // Done initiation + allocate memory
    History* firstHis = new History();
    History* secondHis = new History();
    History* thirdHis = new History();

    //assign value
    firstHis->name = "Ku";
    firstHis->age = 20;
    firstHis->venue = "abc";

    secondHis->name = "qwe";
    secondHis->age = 20;
    secondHis->venue = "qwe";

    thirdHis->name = "zxc";
    thirdHis->age = 20;
    thirdHis->venue = "zxc";

    head = firstHis;
    firstHis->nxtHis = secondHis;
    secondHis->nxtHis = thirdHis;
    thirdHis->nxtHis = NULL;

    displayList(head);

    cout << "-------------------------------------------------------------------------" << endl;

    // Add at head
    History* newHis = new History();

    newHis->name = "asd";
    newHis->age = 11;
    newHis->venue = "lllll";
    newHis->nxtHis = NULL;

    head = addToBegin(newHis, head);
    displayList(head);

    // newHis->nxtHis = head; //Head value is one address 
    // head = newHis; //Head become newHistory addess

    // current = head;

    // while(current != NULL){
    //     cout << current->name << " " << current->age << " " << current->venue << endl;
    //     current = current->nxtHis;
    // }

    cout << "-------------------------------------------------------------------------" << endl;

    // Add at behind
    History* behindHis = new History();

    behindHis->name = "tytyu";
    behindHis->age = 11;
    behindHis->venue = "tyuytu";
    behindHis->nxtHis = NULL;

    head = addToEnd(behindHis, head);
    displayList(head);

    // History* navi = head;
    // while(navi->nxtHis != NULL){
    //     navi = navi->nxtHis;
    // }

    // navi->nxtHis = behindHis;

    // current = head;

    // while(current != NULL){
    //     cout << current->name << " " << current->age << " " << current->venue << endl;
    //     current = current->nxtHis;
    // }

    cout << "-------------------------------------------------------------------------" << endl;
 
    //Insertion at position n
    History* anyPositionHis = new History();
    anyPositionHis->name = "AnyPostion";
    anyPositionHis->age = 20;
    anyPositionHis->venue = "MCD";
    anyPositionHis->nxtHis = NULL;
    
    head = addToN(anyPositionHis, head);
    displayList(head);

    // int n = 3;

    // navi = head;
    // for (int loop =1; loop < n - 1; loop++)
    // {
    //     navi = navi -> nxtHis;
    // }

    // anyPositionHis->nxtHis = navi->nxtHis;
    // navi->nxtHis = anyPositionHis;

    // current = head;

    // while(current != NULL){
    //     cout << current->name << " " << current->age << " " << current->venue << endl;
    //     current = current->nxtHis;
    // }

    cout << "-------------------------------------------------------------------------" << endl;

    // Delete at beginning
    head = delAtBegin(head);
    displayList(head);

    // head = head->nxtHis;
    // current = head;
    // while(current != NULL){
    //     cout << current->name << " " << current->age << " " << current->venue << endl;
    //     current = current->nxtHis;
    // }

    cout << "-------------------------------------------------------------------------" << endl;

    //Delete at behind

    head = delAtEnd(head);
    displayList(head);

    // History* navi = head;
    // while(navi->nxtHis->nxtHis != NULL){
    //     navi = navi->nxtHis;
    // }
    // navi->nxtHis = NULL;
    // current = head;
    // while(current != NULL){
    //     cout << current->name << " " << current->age << " " << current->venue << endl;
    //     current = current->nxtHis;
    // }

    cout << "-------------------------------------------------------------------------" << endl;

   //delete at position n

    head = delAtN(head);
    displayList(head);

    // int delNum = 3;
    // History* navi = head;

    // for(int loop = 2; loop < delNum; loop++){
    //     if (navi->nxtHis != NULL){
    //         navi = navi->nxtHis;
    //     }
    // }

    // navi->nxtHis = navi->nxtHis->nxtHis;

    // current = head;

    // while(current != NULL){
    //     cout << current->name << " " << current->age << " " << current->venue << endl;
    //     current = current->nxtHis;
    // }

    cout << "-------------------------------------------------------------------------" << endl;

    return 0;
}




