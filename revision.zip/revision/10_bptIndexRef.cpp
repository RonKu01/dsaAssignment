#include <iostream>
#include<string>
using namespace std;

const int SIZE = 7;

struct Node{
	char data;
	int left, right;
};

Node indRef[SIZE] = {{'*', 1, 2},
	{'-', 3, 4},
	{'+', 5, 6},
	{'8', -1, -1},
	{'3', -1, -1},
	{'4', -1, -1},
	{'5', -1, -1}};

void displayNode(char data) {
	cout << data << ' ';
}

void preorder(int i) {
	if(i != -1) {
		displayNode(indRef[i].data);
		preorder(indRef[i].left);
		preorder(indRef[i].right);
	}
}

void inorder(int i) {
	if(i != -1) {
		inorder(indRef[i].left);
		displayNode(indRef[i].data);
		inorder(indRef[i].right);
	}
}

void postorder(int i) {
	if(i != -1) {
		postorder(indRef[i].left);
		postorder(indRef[i].right);
		displayNode(indRef[i].data);
	}
}

int main() {
	
	preorder(0);
	cout << endl;
	inorder(0);
	cout << endl;
	postorder(0);
	cout << endl;
	
}