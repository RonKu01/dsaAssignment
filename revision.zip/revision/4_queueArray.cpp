/*Define a structure Product, write a C++ application that implements queue with array to add,
delete and display data of an array of products. Use sentinel controlled looping to enable user to add,
delete or display the details of the product. Use other functions such as isEmpty, isFull in the application.
Do not use a global variable for the array. Pass the array to the add delete and display functions.
As this is a queue program use terms like enqueue for add, dequeue for delete. */

// Modify these codes to complete the program on implementing queue using Linked List. Use enqueue to add data to the queue and dequeue to delete data from the queue. 

/*Complete the codes on Queue with Linked List use enqueue, dequeue and display functions. Use isEmpty().*/ 

#include <iostream>
#include <string>

using namespace std;

const int SIZE = 3;

struct Product
{
	int id;
	string name;
	double price;
};

bool isEmpty(int rear)
{
	return (rear == -1) ? true : false;
}

bool isFull(int rear)
{
	return (rear == SIZE -1) ? true : false;
}

void enque(Product prod[], int& rear, int& front)
{
	if (isFull(rear))
	{
		cout << "Queue is Full!\n";
	}
	else
	{
		if (isEmpty(rear) && isEmpty(front))
		{
			front++;
		}
		rear++;
		cout << "Add Data..\n" << endl;
		cout << "Enter Product ID: ";
		cin >> prod[rear].id;
		cin.ignore(100, '\n');
		cin.clear();
		cout << "Enter Product Name: ";
		getline(cin, prod[rear].name);
		cout << "Enter Product Price: RM ";
		cin >> prod[rear].price;

	}
	system("pause");
}

void deque(Product prod[], int& rear, int front)
{
	if (isEmpty(rear))
	{
		cout << "Queue is Empty!\n";
	}
	else
	{
		cout << "Deleting " << prod[front].id << " - " << prod[front].name << "\n\n";
		for (int i = front; i < rear; i++)
		{
			prod[i].id = prod[i+1].id;
			prod[i].name = prod[i+1].name;
			prod[i].price = prod[i+1].price;
		}
		rear--;
	}
	system("pause");
}

void display(Product prod[], int rear, int front)
{
	if (isEmpty(rear))
	{
		cout << "Queue is Empty!\n";
	}
	else
	{
		cout << "-Display Product List-\n";
		for (int i = front; i <= rear; i++)
		{
			cout << "Product ID: " << prod[i].id << "\n";
			cout << "Product Name: " << prod[i].name << "\n";
			cout << "Product Price: RM " << prod[i].price << "\n";
		}
	}
	system("pause");
}

int main()
{
	Product prodList[SIZE];
	int opt;
	int front = -1, rear = -1;

	do
	{
		cout << "1 - Enque(add)\n"
			<< "2 - Deque(delete)\n"
			<< "3 - Display\n"
			<< "4 - Exit Program \n"
			<< "Select Option: ";
		cin >> opt;

		if (opt == 1 || opt == 2 || opt == 3)
		{
			switch (opt)
			{
			case 1:
				enque(prodList, rear, front);
				system("cls");
				break;
			case 2:
				deque(prodList, rear, front);
				system("cls");
				break;
			case 3:
				display(prodList, rear, front);
				system("cls");
				break;
			default:
				break;
			}
		}
		else
			cout << "Enter only 1 ~ 3, human..\n";
	} while (opt != 4);

	return 0;
}