#include <iostream>
#include <ctime>
#include <string>
using namespace std;

/*The structure for the Email needs to have a pointer to store the address of the next Email node. Else it cannot be a linked list*/

struct email
{
  string name;
  string subject;
  string time;
  int size;

  email *nxtEmail;
};
char ans;
email *top;
email *navi;//if navi is only used within one function then 
//you probably do not need it  to be global

void push ()//do you need to pass the name and subject ftom the main?
{
  email* nEmail= new email();

  cout << "Enter sender`s name: " << endl;
//  cin >> nEmail->name >> nEmail->subject;
  cin.ignore();
  getline(cin, nEmail->name, '\n');

  
  cout << "Enter subject: " << endl;
  getline(cin, nEmail->subject, '\n');

  cout << "Enter message: \n" << endl;
  string message;
  getline(cin, message);
  nEmail -> size = message.size();
  
  nEmail->nxtEmail = NULL;
  nEmail->nxtEmail = top;
  top = nEmail;

  time_t now = time(0);
  char* dt = ctime(&now); 
  nEmail->time = dt;

  /*time and date generator
    struct tm curr_tm;
    time_t curr_time = time(nullptr);

    localtime_r(&curr_time, &curr_tm);

    int curr_year = curr_tm.tm_year + 1900;
    int curr_month = curr_tm.tm_mon + 1;
    int curr_day = curr_tm.tm_mday;
    int curr_hour = curr_tm.tm_hour;
    int curr_minute = curr_tm.tm_min;
    int curr_second = curr_tm.tm_sec;

    printf("%d-%d-%d %d:%d:%d\n", curr_year, curr_month,
           curr_day, curr_hour, curr_minute, curr_second);

    return;*/

}

void display()
{

if (top == NULL)
{
  cout << "Stack is empty" << endl;
  return;
}
  email* navi = top;
while (navi != NULL)
{
  cout << "Sender " << navi->name << endl
  << "Subject " << navi->subject << endl
  << "Time recieved " << navi->time
  << "message size " << navi->size << "kb" <<endl;
  navi = navi->nxtEmail;
  }
  cout << endl;
}

char func_wish()
{
    char ans;
    cout << "Do you want to continue? <Y or N> ";
    cin >> ans;
    return ans;
}
 
int main() {

  int option1;
   do{
  cout << "1: Send email\n";
  cout << "2: Display the list\n";
  cout << "3: Exit Program\n";
  cout << "Please the option you want\n";
  cin >> option1;

  if (option1 <4)
  {
     
    switch (option1){
      case 1: {
        cout << "=====option 1=====\n";
        push();
        break;
      }
      case 2: 
      {
        cout << "=====option 2=====\n";
        display();
        break;
      }
      case 3: {
        cout << "Program is ended\n";
        return 0;
        
      }
     
    } 
    
  }
  }while (option1 == 1|| option1 == 2 || option1 == 3 );
}
